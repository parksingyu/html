/**
 * 
 */
$(function() {
	$('.dropdown').animatedHorizontalNav();
});